import javax.jws.WebService;
import javax.ws.rs.POST;
import javax.ws.rs.Path;

import java.util.ArrayList;
import java.io.*;
import java.rmi.Naming;
import java.rmi.RemoteException;

@WebService(targetNamespace = "http://default_package/", portName = "SoapServerPort", serviceName = "SoapServerService")
public class SoapServer {

    String filePath = "C:\\dev\\SisDistribuidos\\eclipse-workspace\\RestServerProjeto\\src\\main\\java\\pessoa.txt";

	//4.1
	public String listarEspecialidadesREST() {
	    System.out.println("Debug: Endpoint '/ListarEspecialidades' reached.");

	    try {
	        System.out.println("Debug: Calling rmiServer().listarEspecialidades()");

	        // Chama a função RMI para listar as especialidades
	        String result = rmiServer().listarEspecialidades();

	        // Log the result and return it as a JSON response
	        System.out.println("Debug: Result from listarEspecialidades: " + result);
	        return result;

	    } catch (RemoteException e) {
	        System.out.println("Debug: RemoteException occurred: " + e.getMessage());
	        e.printStackTrace();
	        return "{\"error\":\"Erro ao chamar a função listarEspecialidades no servidor RMI.\"}";
	    } catch (Exception e) {
	        System.out.println("Debug: General exception occurred: " + e.getMessage());
	        e.printStackTrace();
	        return "{\"error\":\"Erro inesperado.\"}";
	    }
	}

	public String getClinicasPorEspecialidadeREST(String data) {
	    System.out.println("Debug: Endpoint '/GetClinicasPorEspecialidade' reached.");

	    try {
	        // Parse the input data to get idEspecialidade
	        int idEspecialidade = Integer.parseInt(data.trim());
	        System.out.println("Debug: Parsed idEspecialidade: " + idEspecialidade);

	        System.out.println("Debug: Calling rmiServer().getClinicasPorEspecialidade() with idEspecialidade: " + idEspecialidade);
	        String result = rmiServer().getClinicasPorEspecialidade(idEspecialidade);

	        // Log the result and return it
	        System.out.println("Debug: Result from getClinicasPorEspecialidade: " + result);
	        return result;

	    } catch (NumberFormatException e) {
	        System.out.println("Debug: Invalid especialidade ID format: " + data);
	        return "Erro: Formato inválido para o ID da especialidade.";
	    } catch (RemoteException e) {
	        System.out.println("Debug: RemoteException occurred: " + e.getMessage());
	        e.printStackTrace();
	        return "Erro ao chamar a função getClinicasPorEspecialidade.";
	    } catch (Exception e) {
	        System.out.println("Debug: General exception occurred: " + e.getMessage());
	        e.printStackTrace();
	        return "Erro inesperado.";
	    }
	}

	public String reservarConsultaREST(String data) {
	    System.out.println("Debug: Endpoint '/ReservarConsulta' reached.");

	    try {
	        // Parse the input data
	        String[] parts = data.trim().split(";");
	        if (parts.length != 4) {
	            System.out.println("Debug: Invalid input format: " + data);
	            return "Erro: Formato inválido. Esperado: 'idClinica;idEspecialidade;idUser;dataHora'";
	        }

	        int idClinica = Integer.parseInt(parts[0].trim());
	        int idEspecialidade = Integer.parseInt(parts[1].trim());
	        int idUser = Integer.parseInt(parts[2].trim());
	        String dataHora = parts[3].trim();

	        System.out.println("Debug: Parsed inputs - IdClinica: " + idClinica + ", IdEspecialidade: " + idEspecialidade + ", IdUser: " + idUser + ", DataHora: " + dataHora);

	        // Call the RMI method to reserve the consulta
	        System.out.println("Debug: Calling rmiServer().reservarConsulta() with inputs.");
	        boolean result = rmiServer().reservarConsulta(idClinica, idEspecialidade, idUser, dataHora);

	        // Return the result
	        if (result) {
	            System.out.println("Debug: Consulta reserved successfully.");
	            return "Consulta reservada com sucesso.";
	        } else {
	            System.out.println("Debug: Failed to reserve consulta.");
	            return "Erro: Não foi possível reservar a consulta.";
	        }

	    } catch (NumberFormatException e) {
	        System.out.println("Debug: Invalid input format (NumberFormatException): " + data);
	        return "Erro: Formato inválido para IDs. Certifique-se de que os IDs são numéricos.";
	    } catch (RemoteException e) {
	        System.out.println("Debug: RemoteException occurred: " + e.getMessage());
	        e.printStackTrace();
	        return "Erro ao chamar a função reservarConsulta no servidor.";
	    } catch (Exception e) {
	        System.out.println("Debug: General exception occurred: " + e.getMessage());
	        e.printStackTrace();
	        return "Erro inesperado.";
	    }
	}
	
	//4.2
	public String cancelarConsultaREST(String data) {
	    System.out.println("Debug: Endpoint '/CancelarConsulta' reached.");

	    try {
	        int idConsulta = Integer.parseInt(data.trim());
	        System.out.println("Debug: Parsed idConsulta: " + idConsulta);

	        System.out.println("Debug: Calling rmiServer().cancelarConsulta() with idConsulta: " + idConsulta);
	        boolean result = rmiServer().cancelarConsulta(idConsulta);

	        // Log the result and return it
	        if (result) {
	            System.out.println("Debug: Consulta with idConsulta " + idConsulta + " canceled successfully.");
	            return "Consulta cancelada com sucesso.";
	        } else {
	            System.out.println("Debug: Consulta with idConsulta " + idConsulta + " could not be canceled.");
	            return "Falha ao cancelar a consulta.";
	        }
	    } catch (NumberFormatException e) {
	        System.out.println("Debug: Invalid consulta ID format: " + data);
	        return "Erro: Formato inválido para o ID da consulta.";
	    } catch (RemoteException e) {
	        System.out.println("Debug: RemoteException occurred: " + e.getMessage());
	        e.printStackTrace();
	        return "Erro ao chamar a função cancelarConsulta.";
	    } catch (Exception e) {
	        System.out.println("Debug: General exception occurred: " + e.getMessage());
	        e.printStackTrace();
	        return "Erro inesperado.";
	    }
	}

	//4.3
	public String listarConsultaREST(String data) {
	    System.out.println("Debug: Endpoint '/ListarConsulta' reached.");

	    try {
	        int idUser = Integer.parseInt(data.trim());
	        System.out.println("Debug: Parsed idUser: " + idUser);

	        System.out.println("Debug: a chamar rmiServer().listarConsulta(): " + idUser);
	        String result = rmiServer().listarConsulta(idUser);

	        // Log the result and return it
	        System.out.println("Debug: Result from listarConsulta: " + result);
	        return result;
	        
	    } catch (NumberFormatException e) {
	        System.out.println("Debug: Invalid user ID format: " + data);
	        return "Erro: Formato inválido para o ID do usuário.";
	    } catch (RemoteException e) {
	        System.out.println("Debug: RemoteException occurred: " + e.getMessage());
	        e.printStackTrace();
	        return "Erro ao chamar a função listarConsulta.";
	    } catch (Exception e) {
	        System.out.println("Debug: General exception occurred: " + e.getMessage());
	        e.printStackTrace();
	        return "Erro inesperado.";
	    }
	}
	
	public String autenticar(String data) {
	    System.out.println("Debug: Endpoint '/Autenticar' reached.");
	    System.out.println("Debug: Received data: " + data);

	    String[] info = data.split(";");
	    if (info.length < 2) {
	        System.out.println("Debug: Malformed input. Expected format: 'username;password'.");
	        return "Erro: Input malformado. Esperado 'username;password'.";
	    }

	    String username = info[0].trim();
	    String pw = info[1].trim();

	 ArrayList<String> pessoas = readFromFile(filePath);

	 // Checking if the user exists
        for (String pessoa : pessoas) {
            System.out.println("Debug: Checking pessoa entry: " + pessoa);

            String[] dados = pessoa.split(";");
            if (dados.length == 3) {
                System.out.println("Debug: Parsed pessoa - ID: " + dados[0] + ", Username: " + dados[1]);

                if (dados[1].equals(username) && dados[2].equals(pw)) {
                    System.out.println("Debug: Authentication successful for username: " + username);
                    return dados[0];
                }
            } else {
                System.out.println("Debug: Malformed entry detected: " + pessoa);
            }
        }

	    System.out.println("Debug: Authentication failed for username: " + username);
	    return "-1";
	}
	
	public String registarUtilizador(String data) {
	    System.out.println("Debug: Endpoint '/RegistarUtilizador' reached.");
	    System.out.println("Debug: Received data: " + data);

	    String[] info = data.split(";");
	    if (info.length < 2) {
	        System.out.println("Debug: Malformed input. Expected format: 'username;password'.");
	        return "-1";
	    }

	    String username = info[0].trim();
	    String pw = info[1].trim();
	    
		 ArrayList<String> pessoas = readFromFile(filePath);


		// Checking if the user already exists
        for (String pessoa : pessoas) {
            String[] dados = pessoa.split(";");
            if (dados.length == 3) {
                System.out.println("Debug: Checking pessoa: " + pessoa);
                if (dados[1].equals(username)) {
                    System.out.println("Debug: Username " + username + " already exists. Returning existing ID.");
                    return "-1"; // Return invalid id
                }
            } else {
                System.out.println("Debug: Malformed entry found in pessoas: " + pessoa);
            }
        }

        // Generate a new user ID
        int id = pessoas.size() + 1; // Increment ID by 1 to avoid zero-based indexing
        System.out.println("Debug: New user ID: " + id);

        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath, true))) {
            // Append the new user to the file
            bw.write(id + ";" + username + ";" + pw);
            bw.newLine();
            System.out.println("Debug: New user " + username + " written to file.");
        } catch (IOException e) {
            System.out.println("Debug: Exception occurred while writing to file: " + e.getMessage());
        }

        System.out.println("Debug: User " + username + " registered successfully. ID: " + id);
        return String.valueOf(id);	    
	}
	
	private ArrayList<String> readFromFile(String filePath) {
        ArrayList<String> data = new ArrayList<>();
        try (BufferedReader br = new BufferedReader(new FileReader(filePath))) {
            br.readLine(); // Skip header
            String line;
            while ((line = br.readLine()) != null) {
                data.add(line);
            }
        }
        catch (Exception e){
            System.out.println("erro em readFromFile():" + filePath + " Exception: " + e);
        }

        return data;
    }
	
	private IServerActions rmiServer() {
		try {
            String serverUrl = "rmi://192.168.56.101/rmiServer";
            IServerActions serverActionsInterface = (IServerActions) Naming.lookup(serverUrl);
            
            return serverActionsInterface;
            
        } catch (Exception e) {
            System.out.println("Exception funcao rmiServer(): " + e);
            e.printStackTrace();
            return null;
        }
      
	}
}