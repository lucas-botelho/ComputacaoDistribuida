import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class RegisterFrame extends JFrame {

    public int idUser = -1;

    public RegisterFrame() {
        setTitle("Register");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1));

        JTextField emailField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JLabel messageLabel = new JLabel("", SwingConstants.CENTER);

        JButton registerButton = new JButton("Register");
        JButton backButton = new JButton("Back");

        add(new JLabel("Email:", SwingConstants.CENTER));
        add(emailField);
        add(new JLabel("Password:", SwingConstants.CENTER));
        add(passwordField);
        add(registerButton);
        add(backButton);
        add(messageLabel);

        registerButton.addActionListener((ActionEvent e) -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            if (register(email, password)) {
                messageLabel.setText("Registration successful!");
            } else {
                messageLabel.setText("User already exists!");
            }
        });

        backButton.addActionListener((ActionEvent e) -> {
            dispose();
            new LoginFrame().setVisible(true);
        });
    }

    private boolean register(String email, String pw){

        try {
            URL url = new URL("http://localhost:8080/RestServerProjeto/rest/RegistarUtilizador");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");

            String input = email + ";" + pw;

            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush();

            Scanner scanner;
            String response;
            if (conn.getResponseCode() != 200) {
                scanner = new Scanner(conn.getErrorStream());
                response = "Error From Server \n\n";
            } else {
                scanner = new Scanner(conn.getInputStream());
//                response = "Response From Server \n\n";
            }
            scanner.useDelimiter("\\Z");
//            System.out.println(response + scanner.next());
            int uid = Integer.parseInt(scanner.next());
            scanner.close();
            conn.disconnect();

            if (uid == -1){
                return false;
            }

            idUser = uid;

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return true;
    }
}
