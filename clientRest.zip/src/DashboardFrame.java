import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class DashboardFrame extends JFrame {
    private final DefaultListModel<String> consultationListModel = new DefaultListModel<>();
    private final Map<String, Integer> consultationIdMap = new HashMap<>(); // Stores mapping

    public DashboardFrame(int uId) {
        setTitle("Dashboard");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        JLabel welcomeLabel = new JLabel("Welcome, " + uId, SwingConstants.CENTER);

        JButton reserveButton = new JButton("Reserve Consultation");
        JButton cancelButton = new JButton("Cancel Consultation");
        JButton logoutButton = new JButton("Logout");

        // Create a JList for consultations
        JList<String> consultationList = new JList<>(consultationListModel);
        consultationList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane listScrollPane = new JScrollPane(consultationList);

        // Add a click listener for the consultation list
        consultationList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) { // Double-click event
                    String selectedValue = consultationList.getSelectedValue();
                    Integer id = consultationIdMap.get(selectedValue); // Retrieve the hidden ID
                    JOptionPane.showMessageDialog(DashboardFrame.this,
                            "You selected: " + id,
                            "Consultation Details",
                            JOptionPane.INFORMATION_MESSAGE);
                }
            }
        });

        cancelButton.addActionListener((ActionEvent e) -> {
            int selectedIndex = consultationList.getSelectedIndex(); // Obter índice selecionado
            if (selectedIndex == -1) { // Nenhuma consulta selecionada
                JOptionPane.showMessageDialog(DashboardFrame.this,
                        "Por favor, selecione uma consulta para cancelar.",
                        "Nenhuma Consulta Selecionada",
                        JOptionPane.WARNING_MESSAGE);
            } else {
                String selectedConsultation = consultationListModel.get(selectedIndex);
                System.out.println("Debug: Consulta selecionada para cancelamento: " + selectedConsultation);

                String selectedValue = consultationList.getSelectedValue();
                Integer idConsulta = consultationIdMap.get(selectedValue);

                JOptionPane.showMessageDialog(DashboardFrame.this,
                        cancelar(idConsulta),
                        "Cancelar Consulta",
                        JOptionPane.INFORMATION_MESSAGE);

//                consultationListModel.clear();
                loadConsultations(uId);
            }
        });

        reserveButton.addActionListener((ActionEvent e) -> {
            dispose();
            new ReserveFrame(uId).setVisible(true);
        });


        loadConsultations(uId);

        logoutButton.addActionListener((ActionEvent e) -> {
            dispose();
            new LoginFrame().setVisible(true);
        });

        add(welcomeLabel);
        add(listScrollPane); // Add the consultation list
        add(reserveButton);
        add(cancelButton);
        add(logoutButton);
    }

    private String cancelar(int idConsulta) {
        try {
            URL url = new URL("http://localhost:8080/RestServerProjeto/rest/CancelarConsulta");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");

            String input = "" + idConsulta;

            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush();

            Scanner scanner;
            String response;
            if (conn.getResponseCode() != 200) {
                scanner = new Scanner(conn.getErrorStream());
                response = "Error From Server \n\n";
            } else {
                scanner = new Scanner(conn.getInputStream());
//                response = "Response From Server \n\n";
            }
            scanner.useDelimiter("\\Z");
//            System.out.println(response + scanner.next());


            response = scanner.next();
            scanner.close();
            conn.disconnect();

            return response;

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        return "Nao foi possivel cancelar a consulta";
    }

    private void loadConsultations(int uId) {

        try {
            URL url = new URL("http://localhost:8080/RestServerProjeto/rest/ListarConsulta");
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoOutput(true);
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");

            String input = "" + uId;

            OutputStream os = conn.getOutputStream();
            os.write(input.getBytes());
            os.flush();

            Scanner scanner;
            String response;
            if (conn.getResponseCode() != 200) {
                scanner = new Scanner(conn.getErrorStream());
                response = "Error From Server \n\n";
            } else {
                scanner = new Scanner(conn.getInputStream());
//                response = "Response From Server \n\n";
            }
            scanner.useDelimiter("\\Z");
//            System.out.println(response + scanner.next());


            response = scanner.next();
            scanner.close();
            conn.disconnect();

            if (response.length() > 0){
                consultationListModel.clear();

                if (response.contains(";")){
                    //            1;1;1;2025-11-20 10: 30: 00
                    List<String> consultations = List.of(response.split("\n"));
                    for (String consultation : consultations) {
                        String[] data = consultation.split(";");

                        String idConsulta = data[0];
                        String IdClinica = data[1];
                        String IdMedico = data[2];
                        String DataHora = data[3];
                        String displayValue = "Clinica: " + IdClinica + " Medico: " + IdMedico + " Horario: " + DataHora;
                        consultationListModel.addElement(displayValue); // Add to the visible list
                        consultationIdMap.put(displayValue, Integer.parseInt(idConsulta)); // Map the display value to the hidden ID
                    }
                }
            }

        } catch (MalformedURLException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        //FALTA:
        //endpoint para ir buscar nome medico por id
        //endpoint ir buscar nome clinica por id
    }
}
