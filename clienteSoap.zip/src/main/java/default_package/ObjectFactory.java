
package default_package;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the default_package package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _Autenticar_QNAME = new QName("http://default_package/", "autenticar");
    private final static QName _AutenticarResponse_QNAME = new QName("http://default_package/", "autenticarResponse");
    private final static QName _CancelarConsultaREST_QNAME = new QName("http://default_package/", "cancelarConsultaREST");
    private final static QName _CancelarConsultaRESTResponse_QNAME = new QName("http://default_package/", "cancelarConsultaRESTResponse");
    private final static QName _GetClinicasPorEspecialidadeREST_QNAME = new QName("http://default_package/", "getClinicasPorEspecialidadeREST");
    private final static QName _GetClinicasPorEspecialidadeRESTResponse_QNAME = new QName("http://default_package/", "getClinicasPorEspecialidadeRESTResponse");
    private final static QName _ListarConsultaREST_QNAME = new QName("http://default_package/", "listarConsultaREST");
    private final static QName _ListarConsultaRESTResponse_QNAME = new QName("http://default_package/", "listarConsultaRESTResponse");
    private final static QName _ListarEspecialidadesREST_QNAME = new QName("http://default_package/", "listarEspecialidadesREST");
    private final static QName _ListarEspecialidadesRESTResponse_QNAME = new QName("http://default_package/", "listarEspecialidadesRESTResponse");
    private final static QName _RegistarUtilizador_QNAME = new QName("http://default_package/", "registarUtilizador");
    private final static QName _RegistarUtilizadorResponse_QNAME = new QName("http://default_package/", "registarUtilizadorResponse");
    private final static QName _ReservarConsultaREST_QNAME = new QName("http://default_package/", "reservarConsultaREST");
    private final static QName _ReservarConsultaRESTResponse_QNAME = new QName("http://default_package/", "reservarConsultaRESTResponse");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: default_package
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link Autenticar }
     * 
     */
    public Autenticar createAutenticar() {
        return new Autenticar();
    }

    /**
     * Create an instance of {@link AutenticarResponse }
     * 
     */
    public AutenticarResponse createAutenticarResponse() {
        return new AutenticarResponse();
    }

    /**
     * Create an instance of {@link CancelarConsultaREST }
     * 
     */
    public CancelarConsultaREST createCancelarConsultaREST() {
        return new CancelarConsultaREST();
    }

    /**
     * Create an instance of {@link CancelarConsultaRESTResponse }
     * 
     */
    public CancelarConsultaRESTResponse createCancelarConsultaRESTResponse() {
        return new CancelarConsultaRESTResponse();
    }

    /**
     * Create an instance of {@link GetClinicasPorEspecialidadeREST }
     * 
     */
    public GetClinicasPorEspecialidadeREST createGetClinicasPorEspecialidadeREST() {
        return new GetClinicasPorEspecialidadeREST();
    }

    /**
     * Create an instance of {@link GetClinicasPorEspecialidadeRESTResponse }
     * 
     */
    public GetClinicasPorEspecialidadeRESTResponse createGetClinicasPorEspecialidadeRESTResponse() {
        return new GetClinicasPorEspecialidadeRESTResponse();
    }

    /**
     * Create an instance of {@link ListarConsultaREST }
     * 
     */
    public ListarConsultaREST createListarConsultaREST() {
        return new ListarConsultaREST();
    }

    /**
     * Create an instance of {@link ListarConsultaRESTResponse }
     * 
     */
    public ListarConsultaRESTResponse createListarConsultaRESTResponse() {
        return new ListarConsultaRESTResponse();
    }

    /**
     * Create an instance of {@link ListarEspecialidadesREST }
     * 
     */
    public ListarEspecialidadesREST createListarEspecialidadesREST() {
        return new ListarEspecialidadesREST();
    }

    /**
     * Create an instance of {@link ListarEspecialidadesRESTResponse }
     * 
     */
    public ListarEspecialidadesRESTResponse createListarEspecialidadesRESTResponse() {
        return new ListarEspecialidadesRESTResponse();
    }

    /**
     * Create an instance of {@link RegistarUtilizador }
     * 
     */
    public RegistarUtilizador createRegistarUtilizador() {
        return new RegistarUtilizador();
    }

    /**
     * Create an instance of {@link RegistarUtilizadorResponse }
     * 
     */
    public RegistarUtilizadorResponse createRegistarUtilizadorResponse() {
        return new RegistarUtilizadorResponse();
    }

    /**
     * Create an instance of {@link ReservarConsultaREST }
     * 
     */
    public ReservarConsultaREST createReservarConsultaREST() {
        return new ReservarConsultaREST();
    }

    /**
     * Create an instance of {@link ReservarConsultaRESTResponse }
     * 
     */
    public ReservarConsultaRESTResponse createReservarConsultaRESTResponse() {
        return new ReservarConsultaRESTResponse();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link Autenticar }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link Autenticar }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "autenticar")
    public JAXBElement<Autenticar> createAutenticar(Autenticar value) {
        return new JAXBElement<Autenticar>(_Autenticar_QNAME, Autenticar.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link AutenticarResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link AutenticarResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "autenticarResponse")
    public JAXBElement<AutenticarResponse> createAutenticarResponse(AutenticarResponse value) {
        return new JAXBElement<AutenticarResponse>(_AutenticarResponse_QNAME, AutenticarResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CancelarConsultaREST }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CancelarConsultaREST }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "cancelarConsultaREST")
    public JAXBElement<CancelarConsultaREST> createCancelarConsultaREST(CancelarConsultaREST value) {
        return new JAXBElement<CancelarConsultaREST>(_CancelarConsultaREST_QNAME, CancelarConsultaREST.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link CancelarConsultaRESTResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link CancelarConsultaRESTResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "cancelarConsultaRESTResponse")
    public JAXBElement<CancelarConsultaRESTResponse> createCancelarConsultaRESTResponse(CancelarConsultaRESTResponse value) {
        return new JAXBElement<CancelarConsultaRESTResponse>(_CancelarConsultaRESTResponse_QNAME, CancelarConsultaRESTResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetClinicasPorEspecialidadeREST }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetClinicasPorEspecialidadeREST }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "getClinicasPorEspecialidadeREST")
    public JAXBElement<GetClinicasPorEspecialidadeREST> createGetClinicasPorEspecialidadeREST(GetClinicasPorEspecialidadeREST value) {
        return new JAXBElement<GetClinicasPorEspecialidadeREST>(_GetClinicasPorEspecialidadeREST_QNAME, GetClinicasPorEspecialidadeREST.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link GetClinicasPorEspecialidadeRESTResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link GetClinicasPorEspecialidadeRESTResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "getClinicasPorEspecialidadeRESTResponse")
    public JAXBElement<GetClinicasPorEspecialidadeRESTResponse> createGetClinicasPorEspecialidadeRESTResponse(GetClinicasPorEspecialidadeRESTResponse value) {
        return new JAXBElement<GetClinicasPorEspecialidadeRESTResponse>(_GetClinicasPorEspecialidadeRESTResponse_QNAME, GetClinicasPorEspecialidadeRESTResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListarConsultaREST }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ListarConsultaREST }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "listarConsultaREST")
    public JAXBElement<ListarConsultaREST> createListarConsultaREST(ListarConsultaREST value) {
        return new JAXBElement<ListarConsultaREST>(_ListarConsultaREST_QNAME, ListarConsultaREST.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListarConsultaRESTResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ListarConsultaRESTResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "listarConsultaRESTResponse")
    public JAXBElement<ListarConsultaRESTResponse> createListarConsultaRESTResponse(ListarConsultaRESTResponse value) {
        return new JAXBElement<ListarConsultaRESTResponse>(_ListarConsultaRESTResponse_QNAME, ListarConsultaRESTResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListarEspecialidadesREST }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ListarEspecialidadesREST }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "listarEspecialidadesREST")
    public JAXBElement<ListarEspecialidadesREST> createListarEspecialidadesREST(ListarEspecialidadesREST value) {
        return new JAXBElement<ListarEspecialidadesREST>(_ListarEspecialidadesREST_QNAME, ListarEspecialidadesREST.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListarEspecialidadesRESTResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ListarEspecialidadesRESTResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "listarEspecialidadesRESTResponse")
    public JAXBElement<ListarEspecialidadesRESTResponse> createListarEspecialidadesRESTResponse(ListarEspecialidadesRESTResponse value) {
        return new JAXBElement<ListarEspecialidadesRESTResponse>(_ListarEspecialidadesRESTResponse_QNAME, ListarEspecialidadesRESTResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegistarUtilizador }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RegistarUtilizador }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "registarUtilizador")
    public JAXBElement<RegistarUtilizador> createRegistarUtilizador(RegistarUtilizador value) {
        return new JAXBElement<RegistarUtilizador>(_RegistarUtilizador_QNAME, RegistarUtilizador.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link RegistarUtilizadorResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link RegistarUtilizadorResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "registarUtilizadorResponse")
    public JAXBElement<RegistarUtilizadorResponse> createRegistarUtilizadorResponse(RegistarUtilizadorResponse value) {
        return new JAXBElement<RegistarUtilizadorResponse>(_RegistarUtilizadorResponse_QNAME, RegistarUtilizadorResponse.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReservarConsultaREST }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ReservarConsultaREST }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "reservarConsultaREST")
    public JAXBElement<ReservarConsultaREST> createReservarConsultaREST(ReservarConsultaREST value) {
        return new JAXBElement<ReservarConsultaREST>(_ReservarConsultaREST_QNAME, ReservarConsultaREST.class, null, value);
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ReservarConsultaRESTResponse }{@code >}
     * 
     * @param value
     *     Java instance representing xml element's value.
     * @return
     *     the new instance of {@link JAXBElement }{@code <}{@link ReservarConsultaRESTResponse }{@code >}
     */
    @XmlElementDecl(namespace = "http://default_package/", name = "reservarConsultaRESTResponse")
    public JAXBElement<ReservarConsultaRESTResponse> createReservarConsultaRESTResponse(ReservarConsultaRESTResponse value) {
        return new JAXBElement<ReservarConsultaRESTResponse>(_ReservarConsultaRESTResponse_QNAME, ReservarConsultaRESTResponse.class, null, value);
    }

}
