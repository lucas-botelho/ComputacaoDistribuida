package default_package;
import javax.swing.*;
import java.awt.event.ActionEvent;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class ReserveFrame extends JFrame {

    private final DefaultListModel<String> especialidadeListModel = new DefaultListModel<>();
    private final Map<String, Integer> especidalidadeIdMap = new HashMap<>(); // Stores mapping

    private final DefaultListModel<String> clinicaListModel = new DefaultListModel<>();
    private final Map<String, Integer> clinicaIdMap = new HashMap<>(); // Stores mapping
    private int uid;

    public ReserveFrame(int user) {
        uid = user;
        setTitle("Reserve Consultation");
        setSize(400, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLayout(new BoxLayout(getContentPane(), BoxLayout.Y_AXIS));

        JTextField clinicField = new JTextField();
        JTextField dateField = new JTextField();
        JTextField timeField = new JTextField();
        JLabel messageLabel = new JLabel("", SwingConstants.CENTER);

        JButton reserveButton = new JButton("Reserve");

        JList<String> especialidadeList = new JList<>(especialidadeListModel);
        especialidadeList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane listScrollPane = new JScrollPane(especialidadeList);

        JList<String> clinicaList = new JList<>(clinicaListModel);
        clinicaList.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        JScrollPane clinicaListScrollPane = new JScrollPane(clinicaList);

        // Add a click listener for the consultation list
        especialidadeList.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                if (e.getClickCount() == 2) { // Double-click event
                    String selectedValue = especialidadeList.getSelectedValue();
                    Integer id = especidalidadeIdMap.get(selectedValue);
                    JOptionPane.showMessageDialog(ReserveFrame.this,
                            "You selected: " + id,
                            "Consultation Details",
                            JOptionPane.INFORMATION_MESSAGE);
                }

                if (e.getClickCount() == 1) {
                    String selectedValue = especialidadeList.getSelectedValue();
                    Integer id = especidalidadeIdMap.get(selectedValue);
                    loadClinicas(id);
                }
            }
        });

        JButton backButton = new JButton("Back");
        backButton.addActionListener((ActionEvent e) -> {
            dispose();
            new DashboardFrame(uid).setVisible(true);
        });
        loadEspecidalidade();

        add(new JLabel("Especialidade:"));
        add(listScrollPane);
        add(new JLabel("Clinica:"));
        add(clinicaListScrollPane);
        add(new JLabel("Data (YYYY-MM-DD):"));
        add(dateField);
        add(new JLabel("Hora (HH:MM):"));
        add(timeField);
        add(reserveButton);
        add(backButton);
        add(messageLabel);

        reserveButton.addActionListener((ActionEvent e) -> {
            boolean ok = true;
            String selectedValue = especialidadeList.getSelectedValue();
            int especialidade = especidalidadeIdMap.get(selectedValue);
            selectedValue = clinicaList.getSelectedValue();
            int clinica = clinicaIdMap.get(selectedValue);

            if (especialidadeList.getSelectedValue() == null) {
                JOptionPane.showMessageDialog(this, "Por favor, selecione uma especialidade.", "Erro", JOptionPane.ERROR_MESSAGE);
                ok = false;
            }

            if (clinicaList.getSelectedValue() == null) {
                JOptionPane.showMessageDialog(this, "Por favor, selecione uma clínica.", "Erro", JOptionPane.ERROR_MESSAGE);
                ok = false;
            }


            String date = dateField.getText();
            String time = timeField.getText();

            String dateRegex = "\\d{4}-\\d{2}-\\d{2}"; // YYYY-MM-DD
            String timeRegex = "\\d{2}:\\d{2}";        // HH:MM

            if (!date.matches("\\d{4}-\\d{2}-\\d{2}")) {
                JOptionPane.showMessageDialog(this, "Formato de data invalido! Use YYYY-MM-DD.", "Error", JOptionPane.ERROR_MESSAGE);
                ok = false;
            }

            if (!time.matches("\\d{2}:\\d{2}")) {
                JOptionPane.showMessageDialog(this, "Formato de hora invalido! Use HH:MM.", "Error", JOptionPane.ERROR_MESSAGE);
                ok = false;
            }

            if (ok) {
                reservarConsulta(especialidade, clinica, date, time);
            }

        });
    }

    private void reservarConsulta(int especialidade, int clinica, String date, String time) {
        String input = clinica + ";" + especialidade + ";" + uid + ";" + date + " " + time + ":00";

    	String response = Cliente.createSoapClient().reservarConsultaREST(input);
    	
    	if (response.length() > 0) {
            JOptionPane.showMessageDialog(ReserveFrame.this,
                    response,
                    "Reserva Consulta",
                    JOptionPane.INFORMATION_MESSAGE);
        }
    }

    private void loadEspecidalidade() {
    	
     	String response = Cliente.createSoapClient().listarEspecialidadesREST();
     	
     	 if (response.length() > 0) {
             especialidadeListModel.clear();

             //1;Nome
             List<String> especialidades = List.of(response.split("\n"));
             for (String especialidade : especialidades) {
                 String[] data = especialidade.split(";");

                 String id = data[0];
                 String nome = data[1];
                 String displayValue = nome;
                 especialidadeListModel.addElement(displayValue); // Add to the visible list
                 especidalidadeIdMap.put(displayValue, Integer.parseInt(id)); // Map the display value to the hidden ID
             }
         }
    }

    private void loadClinicas(int idEspecialidade) {
    	
        String input = "" + idEspecialidade;
     	String response = Cliente.createSoapClient().getClinicasPorEspecialidadeREST(input);

     	if (response.length() > 0) {
            clinicaListModel.clear();

            //1;Nome
            List<String> especialidades = List.of(response.split("\n"));
            for (String especialidade : especialidades) {
                String[] data = especialidade.split(";");

                String id = data[0];
                String nome = data[1];
                String displayValue = nome;
                clinicaListModel.addElement(displayValue); // Add to the visible list
                clinicaIdMap.put(displayValue, Integer.parseInt(id)); // Map the display value to the hidden ID
            }
        }
    }
}

