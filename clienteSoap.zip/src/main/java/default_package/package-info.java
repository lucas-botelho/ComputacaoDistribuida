@javax.xml.bind.annotation.XmlSchema(namespace = "http://default_package/")
package default_package;
