package default_package;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;

import java.rmi.Naming;
import java.util.Scanner;
import javax.swing.*;


public class Cliente {

    public static void main(String[] args) throws Exception {
        SwingUtilities.invokeLater(() -> {
            LoginFrame loginFrame = new LoginFrame();
            loginFrame.setVisible(true);
        });
    }

	public static SoapServer createSoapClient() {
	    JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();
	    factory.setAddress("http://localhost:8080/SoapServerProjeto/services/SoapServerPort");
	    factory.setServiceClass(SoapServer.class);
	    return (SoapServer) factory.create();
	}

}
