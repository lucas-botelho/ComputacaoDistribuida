package default_package;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Scanner;

public class RegisterFrame extends JFrame {

    public int idUser = -1;

    public RegisterFrame() {
        setTitle("Register");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1));

        JTextField emailField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JLabel messageLabel = new JLabel("", SwingConstants.CENTER);

        JButton registerButton = new JButton("Register");
        JButton backButton = new JButton("Back");

        add(new JLabel("Email:", SwingConstants.CENTER));
        add(emailField);
        add(new JLabel("Password:", SwingConstants.CENTER));
        add(passwordField);
        add(registerButton);
        add(backButton);
        add(messageLabel);

        registerButton.addActionListener((ActionEvent e) -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            if (register(email, password)) {
                messageLabel.setText("Registration successful!");
            } else {
                messageLabel.setText("User already exists!");
            }
        });

        backButton.addActionListener((ActionEvent e) -> {
            dispose();
            new LoginFrame().setVisible(true);
        });
    }

    private boolean register(String email, String pw){

    	String response = Cliente.createSoapClient().registarUtilizador(email + ";" + pw);
    	
    	int uid = Integer.parseInt(response);

        if (uid == -1){
            return false;
        }

        idUser = uid;
        
        return true;
    }
}
