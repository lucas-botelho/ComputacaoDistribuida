import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.util.Scanner;

public class LoginFrame extends JFrame {
    public int idUser = -1;
    public LoginFrame() {
        setTitle("Login");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(4, 1));

        JTextField emailField = new JTextField();
        JPasswordField passwordField = new JPasswordField();
        JLabel messageLabel = new JLabel("", SwingConstants.CENTER);

        JButton loginButton = new JButton("Login");
        JButton registerButton = new JButton("Register");

        add(new JLabel("Email:", SwingConstants.CENTER));
        add(emailField);
        add(new JLabel("Password:", SwingConstants.CENTER));
        add(passwordField);
        add(loginButton);
        add(registerButton);
        add(messageLabel);

        loginButton.addActionListener((ActionEvent e) -> {
            String email = emailField.getText();
            String password = new String(passwordField.getPassword());

            if (auth(email,password)){
                dispose();
                //new DashboardFrame(idUser).setVisible(true);
            }
            else {
                messageLabel.setText("Invalid credentials!");
            }
        });

        registerButton.addActionListener((ActionEvent e) -> {
            dispose();
            new RegisterFrame().setVisible(true);
        });
    }

    private boolean auth(String email, String pw){

        try {        	
        	int uid = Integer.parseInt(Cliente.createSoapClient().autenticar(email + ";" + pw));
        	
        	if (uid == -1){
                return false;
            }

            idUser = uid;
        } catch (Exception e) {
            e.printStackTrace();
        }

        return true;
    }
}
